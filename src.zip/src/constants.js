export const constants = {
   authApiV1: 'http://localhost/auth/api/v1',
   postApiV1: 'http://localhost/post/api/v1',
}