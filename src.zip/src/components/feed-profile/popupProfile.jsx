import {handleInputFocus,handleInputBlur} from "../popup/popup";


export function popupAuth() {

    return (
        <div className="popup-tab">
            <div className="popup-title"><h3>Create your account</h3></div>
            <div onClick={handleInputFocus} className="popup-input">
                <div className="popup-input__text">
                    <span className='popup-input__text-name'>Name</span>
                    <span className='popup-input__text-symbols'>0/52</span>
                </div>
                <input onBlur={handleInputBlur} type="text"/>
            </div>
            <div onClick={handleInputFocus} className="popup-input">
                <div className="popup-input__text">
                    <span className='popup-input__text-name'>Email</span>
                </div>
                <input onBlur={handleInputBlur} type="text"/>
            </div>
            <div onClick={handleInputFocus} className="popup-input">
                <div className="popup-input__text">
                    <span className='popup-input__text-name'>Password</span>
                    <span className='popup-input__text-symbols'>0/30</span>
                </div>
                <input onBlur={handleInputBlur} type="password"/>
            </div>
            <div onClick={handleInputFocus} className="popup-input">
                <div className="popup-input__text">
                    <span className='popup-input__text-name'>Confirm password</span>
                </div>
                <input onBlur={handleInputBlur} type="password"/>
            </div>

        </div>
    )
}